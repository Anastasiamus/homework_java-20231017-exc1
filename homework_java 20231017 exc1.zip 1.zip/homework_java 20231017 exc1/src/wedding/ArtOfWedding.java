package wedding;

public enum ArtOfWedding {
    GREEN,
    CALICO,
    PAPIER,
    SKIN,
    TREE,
    PINK,
    TURQUEISE,
    SILVER,
    GOLD,
    BRILLIANT
}
