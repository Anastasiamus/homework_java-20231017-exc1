import wedding.ArtOfWedding;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Сколько лет вы состоите в браке:  ?");
        int num = scanner.nextInt();
        ArtOfWedding wedding = switch (num){
            case 1 -> ArtOfWedding.GREEN;
            case 2 -> ArtOfWedding.CALICO;
            case 3 -> ArtOfWedding.PAPIER;
            case 4 -> ArtOfWedding.SKIN;
            case 5 -> ArtOfWedding.TREE;
            case 6 -> ArtOfWedding.PINK;
            case 7 -> ArtOfWedding.TURQUEISE;
            case 8 -> ArtOfWedding.SILVER;
            case 9 -> ArtOfWedding.GOLD;
            case 10 -> ArtOfWedding.BRILLIANT;
            default -> throw new RuntimeException("error");

        };
        System.out.println(wedding);
        String description = switch (wedding){
            case GREEN -> " together not more then one year ";
            case CALICO -> " one year together ";
            case PAPIER -> " two years together ";
            case SKIN -> " three years together ";
            case TREE -> " five years together ";
            case PINK -> " ten years together ";
            case TURQUEISE -> " eighteen years together ";
            case SILVER -> " twenty-five years together";
            case GOLD -> " fifty years together";
            case BRILLIANT -> " sixty years together ";
        };
        System.out.println(description);

    }
}






// 1 уровень сложности: Задание 1.
//Пользователь вводит, сколько лет он состоит в браке.
// Программа должна вывести, какая годовщина свадьбы будет у пользователя следующей
// (бумажная, ситцевая, чугунная, серебряная и.д.).
// Не обязательно указывать все годовщины, достаточно 10-15. Узнать про годовщины можно,
// например, здесь https://instalook.ru/blog/nazvaniya-vseh-godovschin-svadeb-do-100-let